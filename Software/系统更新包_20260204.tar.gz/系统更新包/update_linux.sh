#!/bin/bash

# set -e

KERNEL_VERSION=5.4.61-rt37

DIR_UPDATE=./update_files
DIR_UPDATE_BOOTLOADER=${DIR_UPDATE}/bootloader
DIR_UPDATE_KERNEL=${DIR_UPDATE}/kernel
DIR_UPDATE_ROOTFS=${DIR_UPDATE}/rootfs
DIR_UPDATE_DRIVERS=${DIR_UPDATE}/drivers
DIR_UPDATE_TEST=${DIR_UPDATE}/test
DIR_UPDATE_LIB=${DIR_UPDATE}/lib

DIR_ETC=/etc
DIR_DEV=/dev

FILE_BOOTLOADER_BOOT0=${DIR_UPDATE_BOOTLOADER}/boot0_sdcard.fex
FILE_BOOTLOADER_UBOOT=${DIR_UPDATE_BOOTLOADER}/boot_package.fex
FILE_BOOTLOADER_BOOT_RESOURCE=${DIR_UPDATE_BOOTLOADER}/boot-resource.fex
FILE_BOOTLOADER_GPT_BACKUP=${DIR_UPDATE_BOOTLOADER}/backup_gpt.bin
FILE_BOOTLOADER_ENV=${DIR_UPDATE_BOOTLOADER}/uboot_env.img
FILE_BOOTLOADER_ENV_REDUND=${DIR_UPDATE_BOOTLOADER}/uboot_env-redund.img

FILE_BOOTLOADER_DTBO=${DIR_UPDATE_BOOTLOADER}/wld2660-overlay-1.dtb
FILE_DTBO_DEFAULT_NAME=dts-overlay-1.dtbo

FILE_KERNEL_IMG=${DIR_UPDATE_KERNEL}/uImage_5.10
FILE_ROOTFS_IMG=${DIR_UPDATE_ROOTFS}/sanway-emmc-rootfs-10.2-qt5.12.-jdk8-python3.8.10_t536.ext4
FILE_RC_LOCAL=rc.local

#mmc变量默认定义
MMC_DEV=${DIR_DEV}/mmcblk0
TF_DEV=${DIR_DEV}/mmcblk1
MMC_COUNT=1

#mmc分区定义
#T113i eMMC官方默认的分区定义信息：
# Number  Start (sector)    End (sector)  Size Name
#   1           73728          108165   16.8 MiB    0700  boot-resource
#   2          108166          110213   1024.0 KiB  0700  env
#   3          110214          112261   1024.0 KiB  0700  env-redund
#   4          112262          147461   17.2 MiB    0700  boot
#   5          147462         2244613   1024.0 MiB  0700  rootfs
#   6         2244614         2246661   1024.0 KiB  0700  dsp0
#   7         2246662         2279429   16.0 MiB    0700  private
#   8         2279430         7733214   2.6 GiB     0700  UDISK

#我将其修改如下：
# Number  Start (sector)    End (sector)  Size Name
#   1           73728          108165   16.8 MiB    0700  boot-resource
#   2          108166          110213   1024.0 KiB  0700  env
#   3          110214          112261   1024.0 KiB  0700  env-redund
#   4          112262          147461   17.2 MiB    0700  boot
#   5          147462         2244613   1024.0 MiB  0700  rootfs
#   6         2244614         2246661   1024.0 KiB  0700  dtb
#   7         2246662         2279429   16.0 MiB    0700  private
#   8         2279430         7733214   2.6 GiB     0700  UDISK

arr_part_name=("boot-resource" "env" "boot" "private" "rootfs" "dtb" "UDISK")

PART_NO_BOOT_RESOURCE=p1
PART_NO_ENV=p2
PART_NO_ENV_REDUND=p3
PART_NO_KERNEL=p4
PART_NO_ROOTFS=p5
PART_NO_DTB=p6
PART_NO_PRIVATE=p7
PART_NO_UDISK=p8

PART_MMC_BOOT_RESOURCE=${MMC_DEV}${PART_NO_BOOT_RESOURCE}
PART_MMC_ENV=${MMC_DEV}${PART_NO_ENV}
PART_MMC_ENV_REDUND=${MMC_DEV}${PART_NO_ENV_REDUND}
PART_MMC_KERNEL=${MMC_DEV}${PART_NO_KERNEL}
PART_MMC_ROOTFS=${MMC_DEV}${PART_NO_ROOTFS}
PART_MMC_DTB=${MMC_DEV}${PART_NO_DTB}
PART_MMC_UDISK=${MMC_DEV}${PART_NO_UDISK}

#默认更新模式：all，全部更新
UPDATE_MODE_DEFAULT=all

shell_color_set()
{
        #red='\[\e[0;31m\]'
        red='\e[1;31m'
        RED='\e[1;31m'
        blue='\e[0;34m'
        BLUE='\e[1;34m'
        cyan='\e[0;36m'
        CYAN='\e[1;36m'
        green='\e[0;32m'
        GREEN='\e[1;32m'
        yellow='\e[1;33m'
        YELLOW='\e[1;33m'
        PURPLE='\e[1;35m'
        purple='\e[0;35m'

        error='\e[1;41m'
        warn='\e[1;43m'

        nc='\e[0m'

        # RED='\033[0;31m'
        # GREEN='\033[0;32m'
        # NC='\033[0m' # No Color                                                                  
}

shell_display_color_words()
{
        shell_color_set

        case $1 in
        yellow)
                echo -e -n "${yellow}$2${nc}"
                ;;
        YELLOW)
                echo -e "${YELLOW}$2${nc}"
                ;;
        cyan)
                echo -e -n "${cyan}$2${nc}"
                ;;
        CYAN)
                echo -e "${CYAN}$2${nc}"
                ;;
        green)
                #echo "\033[32m$2\033[0m"
                echo -e -n "${green}$2${nc}"
                ;;
        GREEN)
                #echo "\033[32m$2\033[0m"
                echo -e "${GREEN}$2${nc}"
                ;;

        red)
                #echo "\033[31m$2\033[0m"
                echo -e "${red}$2${nc}"
                ;;

        RED)
                #echo "\033[31m$2\033[0m"
                echo -e "${RED}$2${nc}"
                ;;
        blue)
                #echo "\033[34m$2\033[0m"
                echo -e "${blue}$2${nc}"
                ;;
        BLUE)
                #echo "\033[34m$2\033[0m"
                echo -e "${BLUE}$2${nc}"
                ;;
        white)
                #echo "\033[40;37m$2\033[0m"
                echo -e "\033[37m$2\033[0m"
                ;;
        error)
                echo -e "${error}$2${nc}"
                ;;
        warn)
                #echo -e "${warn}$2${nc}"
                echo -e "${YELLOW}$2${nc}"
                ;;
        *)
                echo "$2"
                ;;
        esac
}

#检测MTD的编号，可以输入1个参数，或者2个参数。
#采用2个参数是指：当出现搜索出2个以上的结果时，第2个参数用于排除多个选项，最终只保留一个结果。
detect_mtd()
{
        if [ $# -lt 1 ]
        then
                echo Error: No paramter! You must specify at least 1 paramter.
                exit 1
        fi

        if [ $# -eq 2 ]; then
                PARAM1=$1
                PARAM2=$2
                MTD_NAME=`cat /proc/mtd | grep "${PARAM1}" | grep -v "${PARAM2}" | cut -d ":" -f1`
        else
                PARAM1=$1
                MTD_NAME=`cat /proc/mtd | grep "${PARAM1}" | cut -d ":" -f1`
        fi

        # echo param1: ${PARAM1}        
        if [ -z ${MTD_NAME} ]; then
                echo Cannot find ${PARAM1} partition!
                exit 1                
        fi

        echo ${PARAM1} partition name: ${MTD_NAME}

        MTD_NUMBER=`echo ${MTD_NAME} | cut -d "d" -f2`
        MTD_BLOCK_NAME=${DIR_DEV}/mtdblock${MTD_NUMBER}

        echo ${PARAM1} block partition: ${MTD_BLOCK_NAME}
}

check_file_exist()
{
        if [ $# -ne 1 ]
        then
                echo Error: No paramter! You must specify 1 paramter.
                exit 1
        fi

        if [ ! -e $1 ]
        then                
                echo File: $1 is not exist!
                exit 1
        fi

        return 0
}

check_directory_exist()
{
        if [ $# -ne 1 ]
        then
                echo Error: No paramter! You must specify 1 paramter.
                exit 1
        fi

        if [ ! -d $1 ]; then
                echo DIR: $1 is not exist!
                exit 1
        fi

        #echo DIR: $1 is OK.
        return 0
}

#复制文件：需要2个参数$1和$2
update_files()
{
        check_directory_exist $2
        check_file_exist $1        

        echo Copying file: $1 to $2 ...
        cp -raf $1 $2

        if [ $? -ne 0 ]; then
                shell_display_color_words error "Copying file $1 failed."
                exit 1
        fi

        shell_display_color_words GREEN "Copy file $1 to $2 suceeded!"
        echo ""
}

#复制文件：需要2个参数$1和$2
update_tar_bag()
{                                                            
        check_directory_exist $2
        check_file_exist $1        

        echo Extracting TAR bag file: $1 to dir: $2 ...
        tar xzvf $1 -C $2

        if [ $? -ne 0 ]; then
                shell_display_color_words error "Extracting TAR bag file $1 to dir: $2 failed."
                exit 1
        fi

        shell_display_color_words GREEN "Extracting TAR bag file $1 to dir: $2 suceeded!"
        echo ""
}

check_block_device_exist()
{
        if [ $# -ne 1 ]
        then
                echo Error: No paramter! You must specify 1 paramter.
                exit 1
        fi

        if [ ! -b $1 ]; then
                echo Device block: $1 is not exist!
                exit 1
        fi

        #echo Device block: $1 is OK.
        return 0
}

#采用dd命令烧写eMMC分区
#参数1为需要烧写的文件名，参数2为eMMC分区编号，如mmcblk0p3等
erase_and_write_emmc()
{
        if [ $# -ne 2 ]
        then
                echo Error: No paramter! You must specify 2 paramter.
                exit 1
        fi

        check_block_device_exist $2
        check_file_exist $1
        
        echo Writing $1 to $2 ...
        echo "dd if=$1 of=$2 bs=1M"

        dd if=$1 of=$2 bs=1M

        if [ $? -ne 0 ]; then                
                shell_display_color_words error "Writing $1 failed."
                exit 1
        fi
        
        shell_display_color_words GREEN "Writing $1 to $2 succeeded!"
        echo ""
        return 0
}

#采用dd命令烧写eMMC分区，且dd命令需要带seek偏移量
#参数1为需要烧写的文件名，参数2为eMMC分区编号，如mmcblk0p3等，参数3为seek偏移量
erase_and_write_emmc_seek()
{
        local DD_BS=512
        local DD_CONV=notrunc

        if [ $# -ne 3 ]
        then
                echo "Error: No paramter! You must specify 3 paramters."
                echo "Usage: $0 <file> <block_device> <seek_offset>"
                exit 1
        fi

        check_block_device_exist $2
        check_file_exist $1
        
        echo Writing $1 to $2 with seek offset: $3 ...
        echo "dd if=$1 of=$2 seek=$3 conv=${DD_CONV} bs=${DD_BS}"

        dd if=$1 of=$2 seek=$3 conv=${DD_CONV} bs=${DD_BS}

        if [ $? -ne 0 ]; then                
                shell_display_color_words error "Writing $1 to $2 with seek offset: $3 failed."
                exit 1
        fi
        
        shell_display_color_words warn "Writing $1 to $2 with seek offset: $3 succeeded!"
        echo ""
        return 0
}

detect_rootfs_partition()
{
        local PARTITITON_ROOTS=$(cat /proc/cmdline | grep "root=" | awk -F= '{print $6}' | awk '{print $1}')
        echo Current loading rootfs partition: ${PARTITITON_ROOTS}

        #以下判断写法是判断一个字符串是否包含子字符串
        if [[ "${PARTITITON_ROOTS}" == *"${MMC_DEV}"* ]]; then
                shell_display_color_words error "Current file system is loading by: EMMC."
                shell_display_color_words error "We can not update rootfs, you must restart system in TF Card mode, and rerun script: $0"
                exit 1  
        elif [[ "${PARTITITON_ROOTS}" == *"${TF_DEV}"* ]]; then
                echo "Current file system is loading by: TF_CARD."
                shell_display_color_words GREEN "Checking rootfs OK, we can update rootfs."
        else
                shell_display_color_words error "Current file system is loading UNKNOWN, We can not update rootfs."
                exit 1
        fi                    
}

show_system_menu()
{
        local num_items=4
        arr_update_mode=("all" "kernel" "dtb" "rootfs" "spl" "uboot_env" "gpt")

        echo "==================================================================="
        echo "Welcome to Sanway Linux Update Script, please choose update mode:"
        echo "1. all - Update all bootloader/kernel/rootfs/spl/uboot_env/gpt to eMMC device"
        echo "2. kernel - Update kernel to eMMC/TF_CARD only"
        echo "3. dtb - Update dtbo file to eMMC/TF_CARD only"
        echo "4. rootfs - Update rootfs to eMMC only"
        echo ""

        echo -n "Please input your choice: [1-4] " && read items
        if [ -z ${items} ]; then
                shell_display_color_words error "You did not input any choice, please re-run script: $0"
                exit 1
        fi

        if [ ${items} -lt 1 ] || [ ${items} -gt ${num_items} ]; then
                shell_display_color_words error "You input invalid choice: ${items}, please re-run script: $0"
                exit 1
        fi

        UPDATE_MODE=${arr_update_mode[$((items-1))]}
}

detect_input_paramters()
{
        # echo Paramter is: $#
        if [ $# -lt 1 ]; then
                # UPDATE_MODE=${UPDATE_MODE_DEFAULT}
                # echo You are not inputting paramters, we use default update mode: ${UPDATE_MODE}
                show_system_menu
        else
                UPDATE_MODE=$1                
        fi

	# arr_update_mode=("all" "kernel" "rootfs" "spl" "uboot_env" "gpt")

	##遍历数组
	# for item in "${arr_update_mode[@]}"; do
	    ##echo "$item"
	#     if [ "$item" = "${UPDATE_MODE}" ]; then
	        # echo Current update mode: ${UPDATE_MODE}
		# echo ""
		# return 0
	#     fi
	# done

        case ${UPDATE_MODE} in
        all)
                echo Current update mode: ${UPDATE_MODE}
                echo ""
                return 0
                ;;
        kernel)
                echo Current update mode: ${UPDATE_MODE}
                echo ""
                return 0
                ;;
        dtb)
                echo Current update mode: ${UPDATE_MODE}
                echo ""
                return 0
                ;;
        rootfs)
                echo Current update mode: ${UPDATE_MODE}
                echo ""
                return 0
                ;;
        spl)
                echo Current update mode: ${UPDATE_MODE}
                echo ""
                return 0
                ;;
        uboot_env)
                echo Current update mode: ${UPDATE_MODE}
                echo ""
                return 0
                ;;
        gpt)
                echo Current update mode: ${UPDATE_MODE}
                echo ""
                return 0
                ;;
        *)
                shell_display_color_words error "Update mode select error: ${UPDATE_MODE}"
                echo You should input paramter such as: all/kernel/rootfs/spl/uboot_env/gpt, etc.
                echo The default update mode is: ${UPDATE_MODE_DEFAULT}
                exit 1
                ;;
        esac
}

update_mmc_choice()
{
	echo -n "请选择想要更新哪个MMC设备的${UPDATE_MODE}镜像分区: [0 - eMMC/1 - TF_CARD] " && read items

	if [ -z ${items} ]; then
		shell_display_color_words error "你没有输入任何选项，请重新运行脚本！"
		exit 1
	elif [ "$items" = "0" ]; then
		MMC_CHOICE_DEV=${MMC_DEV}		
	elif [ "$items" = "1" ]; then
		MMC_CHOICE_DEV=${TF_DEV}
	else
		shell_display_color_words error "你输入的选项错误，请重新运行脚本！"
		exit 1
	fi
}

mkdir_and_mount_rootfs()
{
        if [ $# -ne 2 ]; then
                shell_display_color_words error "mkdir_and_mount_rootfs: invalid parameter."
                exit 1
        fi
        local DIR_MNT=$2
        mkdir -p ${DIR_MNT}
        mount $1 ${DIR_MNT}
        if [ $? -ne 0 ]; then                
                shell_display_color_words error "Mount ${PART_MMC_ROOTFS} to ${DIR_MNT} failed."
                exit 1
        else
                shell_display_color_words GREEN "Mount ${PART_MMC_ROOTFS} to ${DIR_MNT} succeeded!"
        fi
}

update_uboot_env()
{
        #更新uboot环境变量
        local DIR_BOOT=/boot
        local FILE_UBOOT_ENV=${DIR_UPDATE_BOOTLOADER}/uEnv.txt

        update_files ${FILE_UBOOT_ENV} ${DIR_BOOT}
}

update_kernel()
{
        #更新内核映像
        local DIR_ROOTFS_BASE=/
        local DIR_BOOT=/boot
        local DIR_KERNEL_MODULES=/lib/modules/

        update_files ${FILE_KERNEL_IMG} ${DIR_BOOT}

        #更新内核模块
        local FILE_LIB_MODULES=${DIR_UPDATE_KERNEL}/5.10.10-sanway_20260123.tar.gz

        rm -rf ${DIR_KERNEL_MODULES}/5.10.10-sanway
        if [ -f ${FILE_LIB_MODULES} ]; then
                if [ ! -d ${DIR_KERNEL_MODULES} ]; then
                        mkdir -p ${DIR_KERNEL_MODULES}
                        shell_display_color_words GREEN "Make directory ${DIR_KERNEL_MODULES} succeeded."
                fi
                update_tar_bag ${FILE_LIB_MODULES} ${DIR_KERNEL_MODULES}
                depmod -b ${DIR_ROOTFS_BASE} $(uname -r)
        fi
}

dtb_file_select()
{
        local dir=${DIR_UPDATE_BOOTLOADER}/dtb

        files=()
        i=1
        for file in "$dir"/*; do
                if [ -f "$file" ]; then
                        files+=("$file")
                        echo "$i: $(basename "$file")"
                        ((i++))
                fi
        done

        if [ ${#files[@]} -eq 0 ]; then
                echo "目录下没有文件"
                exit 0
        fi

        read -p "请选择文件编号: " choice

        if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#files[@]}" ]; then
                echo "你选择了: ${files[$((choice-1))]}"
                FILE_BOOTLOADER_DTBO=${files[$((choice-1))]}
        else
                echo "无效选择"
                exit 0
        fi
}

update_dtb()
{
        local DIR_BOOT=/boot
        local FILE_SYSLINUX_CONFIG=${DIR_UPDATE_BOOTLOADER}/extlinux.conf
        local DIR_SYSLINUX_CONFIG=${DIR_BOOT}/mmc1_stm32mp157d-ev1_extlinux

        dtb_file_select    
        echo FILE: ${FILE_BOOTLOADER_DTBO}
        
        update_files ${FILE_BOOTLOADER_DTBO} ${DIR_BOOT}

        #更新syslinux配置文件
        update_files ${FILE_SYSLINUX_CONFIG} ${DIR_SYSLINUX_CONFIG}
}

install_rootfs()
{
        #更新rootfs系统文件
        local TAR_BAG_FILE_SANWAY=${DIR_UPDATE_ROOTFS}/sanway_swm3310_v1.0_20260127.tar.gz
        local FILE_ISSUE=${DIR_UPDATE_ROOTFS}/issue
        local FILE_HOSTNAME=${DIR_UPDATE_ROOTFS}/hostname
        local FILE_RULES=${DIR_UPDATE_ROOTFS}/*.rules


        #更新主机名
        update_files ${FILE_HOSTNAME} /etc/
        update_files ${FILE_ISSUE} /etc/

        #更新udev规则
        cp -raf ${FILE_RULES} /etc/udev/rules.d/
        if [ $? -ne 0 ]
        then
                shell_display_color_words error "Update udev rules failed."
                exit 1
        else
                shell_display_color_words GREEN "Update udev rules success."
        fi

        #更新sanway文件
        rm -rf /usr/local/sanway
        update_tar_bag ${TAR_BAG_FILE_SANWAY} /usr/local/

        #更新动态链接库
        local LIB_CPLD_TAR_BAG=${DIR_UPDATE_LIB}/libswm3310.tar.gz

        if [ -f ${LIB_CPLD_TAR_BAG} ]; then
                shell_display_color_words GREEN "Update CPLD lib FILE: ${LIB_CPLD_TAR_BAG}"                
                update_tar_bag ${LIB_CPLD_TAR_BAG} /usr/lib/
        fi

        #更新SWM3310测试程序
        local FILE_TEST_SWM3310=test_swm3310
        if [ -f ${DIR_UPDATE_TEST}/${FILE_TEST_SWM3310} ]; then
                shell_display_color_words GREEN "Update SWM3310 test FILE: ${FILE_TEST_SWM3310}"
                update_files ${DIR_UPDATE_TEST}/${FILE_TEST_SWM3310} /usr/bin/
                chmod +x /usr/bin/${FILE_TEST_SWM3310}
        fi
}

update_rootfs()
{             
        install_rootfs
}

update_all()
{        
        # shell_display_color_words  green "现在更新bootloader..."
        # echo ""
        # sleep 1
        # update_spl

        shell_display_color_words  green "现在更新内核映像..."
        echo ""
        sleep 1
        update_kernel

        shell_display_color_words  green "现在更新dtb分区..."
        echo ""
        sleep 1
        update_dtb

        shell_display_color_words  green "现在更新文件系统..."
        echo ""
        sleep 1
        update_rootfs
}

#使用sgdisk命令对eMMC进行分区
emmc_sgdisk_partitions()
{
	#sgdisk --resize-table=128 -a 1 -n 1:34:4129 -c 1:ssbl -p /dev/mmcblk1 
	#sgdisk --resize-table=128 -a 1 -n 2:4130:135201 -c 2:bootfs -p /dev/mmcblk1
	#sgdisk -n 1:1MiB:+1MiB -t 1:ef02 -c 1:grub /dev/sda

	return 0
}

#备份GPT分区表，需要带1个参数，参数为mmc设备名称，如/dev/mmcblk1
mmc_gpt_backup()
{
	if [ $# -ne 1 ]; then
		echo "Usage: $0 <mmc_device>"
		exit 1
	fi

	# 检查输入的设备是否存在
        check_block_device_exist $1

	local MMC_BACKUP=$1
	echo "Backing up GPT partition table from device: ${MMC_BACKUP}"
	# 获取磁盘总扇区数
	# SECTORS=$(cat /sys/block/${MMC_BACKUP}/size)

	#备份主分区表
	# dd if=/dev/${MMC_BACKUP} of=gpt_main_table.bin bs=512 seek=0 count=16

	# 备份最后 33 个扇区（GPT 备份表通常占用最后 33 个扇区）
	# dd if=/dev/${MMC_BACKUP} of=gpt_backup_table.bin bs=512 skip=$((SECTORS-33)) count=33

	sgdisk --backup=${FILE_BOOTLOADER_GPT_BACKUP} ${MMC_BACKUP}
	if [ $? -ne 0 ]; then
		shell_display_color_words error "Error: Failed to backup ${MMC_BACKUP} GPT partition table."
		exit 1
	fi

	shell_display_color_words GREEN "${MMC_BACKUP} GPT partition table backup successfully."
}

#恢复GPT分区表，需要带1个参数，参数为mmc设备名称，如mmcblk1
mmc_gpt_restore()
{
	if [ $# -ne 1 ]; then
		echo "Usage: $0 <mmc_device>"
		exit 1
	fi

	# 检查输入的设备是否存在
        check_block_device_exist $1

	local MMC_RESTORE=$1

	# 恢复主分区表
	# dd if=gpt_main_table.bin of=/dev/${MMC_RESTORE} bs=512 seek=0 count=16

	# 恢复最后 33 个扇区（GPT 备份表通常占用最后 33 个扇区）
	# dd if=gpt_backup_table.bin of=/dev/${MMC_RESTORE} bs=512 skip=$((SECTORS-33)) count=33

	check_file_exist ${FILE_BOOTLOADER_GPT_BACKUP}

	sgdisk --load-backup=${FILE_BOOTLOADER_GPT_BACKUP} ${MMC_RESTORE}
	if [ $? -ne 0 ]; then
		shell_display_color_words error "Error: Failed to restore ${MMC_RESTORE} GPT partition table."
		exit 1
	fi

	shell_display_color_words GREEN "${MMC_RESTORE} GPT partition table restored successfully from backup."
}

show_mmc_part()
{
        if [ $# -ne 1 ]; then
                echo "Usage: $0 <mmc_device>"
                exit 1
        fi

        # arr_part_name=("boot-resource" "env" "boot" "private" "rootfs" "riscv0" "UDISK")

        for i in "${arr_part_name[@]}"; do
                local MMC_PART_NAME=$i                
                PART_NO=$(sgdisk -p $1 | grep -E "[[:space:]]${MMC_PART_NAME}[[:space:]]*$" | awk '{print $1}')
                if [ -z "${PART_NO}" ]; then
                        echo "分区名称: $i, 未找到对应的分区号"
                        continue
                fi

                PART_NO=p${PART_NO}
                
                case $i in
                        "boot-resource")
                                PART_MMC_BOOT_RESOURCE=${1}${PART_NO}
                                PART_NO_BOOT_RESOURCE=${PART_NO}
                                echo -e "分区名称: $i, ${PART_MMC_BOOT_RESOURCE}"
                                ;;
                        "env")
                                PART_MMC_ENV=${1}${PART_NO}
                                PART_NO_ENV=${PART_NO}
                                echo -e "分区名称: $i, ${PART_MMC_ENV}"
                                ;;
                        "boot")
                                PART_MMC_KERNEL=${1}${PART_NO}
                                PART_NO_KERNEL=${PART_NO}
                                echo -e "分区名称: $i, ${PART_MMC_KERNEL}"
                                ;;                                                                                                
                        "rootfs")
                                PART_MMC_ROOTFS=${1}${PART_NO}
                                PART_NO_ROOTFS=${PART_NO}
                                echo -e "分区名称: $i, ${PART_MMC_ROOTFS}"
                                ;;
                        "dtb")
                                PART_MMC_DTB=${1}${PART_NO}
                                PART_NO_DTB=${PART_NO}
                                echo -e "分区名称: $i, ${PART_MMC_DTB}"
                                ;;
                        "UDISK")
                                PART_MMC_UDISK=${1}${PART_NO}
                                PART_NO_UDISK=${PART_NO}
                                echo -e "分区名称: $i, ${PART_MMC_UDISK}"
                                ;;
                        *)
                                echo -e "分区名称: $i, ${1}${PART_NO}"
                                ;;
                esac
                        
        done

        echo "==================================================================="
        echo ""
}

detect_emmc_is_parted()
{
        MMC_DEV=${DIR_DEV}/mmcblk1
        local PART_COUNT=$(ls ${MMC_DEV}p* 2>/dev/null | wc -l)

        if [ "$PART_COUNT" -gt 0 ]; then
            echo "eMMC 已分区，分区数: $PART_COUNT"
            show_mmc_part ${MMC_DEV}
            return 0
        else
            shell_display_color_words YELLOW "eMMC 未分区，请先分区！"
        fi
        
        echo -n "现在需要对eMMC开始分区吗？ [y/n/q] " && read items

        if [ -z "$items" ]; then
            shell_display_color_words YELLOW "你未做任何选择，脚本退出！"
            exit 0
        fi

        if [ "$items" = "q" ] || [ "$items" = "n" ]; then
            shell_display_color_words YELLOW "你选择了退出，脚本退出！"
            exit 0
        fi

        if [ "$items" = "y" ]; then
            echo "你选择了分区，现在开始分区..."
            mmc_gpt_restore ${MMC_DEV}
        fi  

        #分区完成后，再次显示分区信息
        show_mmc_part ${MMC_DEV}

        #还需要将rootfs分区和UDISK分区格式化一下
        shell_display_color_words GREEN "Formatting rootfs and UDISK partitions ..."
        mkfs.ext4 -F ${PART_MMC_ROOTFS}
        if [ $? -ne 0 ]; then
                shell_display_color_words error "mkfs.ext4 ${PART_MMC_ROOTFS} failed."
                exit 1
        fi

        mkfs.ext4 -F ${PART_MMC_UDISK}
        if [ $? -ne 0 ]; then
                shell_display_color_words error "mkfs.ext4 ${PART_MMC_UDISK} failed."
                exit 1
        fi
}

detect_system()
{
        #detect_mmc_type
        #detect_emmc_is_parted
        echo ""
}

update_gpt()
{
	# echo "GPT脚本函数尚未完成！"
	# exit 1

	echo -n "你是要备份还是恢复GPT分区表？ [b - 备份/r - 恢复] " && read opmode
	if [ "$opmode" != "b" ] && [ "$opmode" != "r" ]; then				
		shell_display_color_words error "Error: Invalid operation mode: $opmode"
		exit 1
	fi

	if [ ${UPDATE_MODE} != "all" ] && [ ${MMC_COUNT} -gt 1 ]; then
		update_mmc_choice
		MMC_DEV=${MMC_CHOICE_DEV}
	fi        
	
	echo MMC: ${MMC_DEV}
	echo FILE: ${FILE_BOOTLOADER_GPT_BACKUP}

	if [ "$opmode" = "b" ]; then
		# 备份GPT分区表
		mmc_gpt_backup ${MMC_DEV}
	else										
		mmc_gpt_restore ${MMC_DEV}
	fi
}

###############################################################
#主脚本代码开始
###############################################################

#检测输入参数
detect_input_paramters $1
echo "==================================================================="
echo ""

detect_system

# echo Now we coming into update ${UPDATE_MODE} mode ...       
update_${UPDATE_MODE}

sync
sleep 1
echo Operating finished, Now you need poweroff, and restart system ...
exit 0
